package com.auth.authentication.controller;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.auth.authentication.entity.User;
import com.auth.authentication.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class AuthController {
	
	private final UserService userService;

	@GetMapping
	String getMessage() {
		return "Hello";
	}
	@PostMapping
	String postMessage(@RequestBody String message) {
		return message;
	}
	@GetMapping("/csrf")
	CsrfToken csrfToken(HttpServletRequest request) {
		CsrfToken token =(CsrfToken) request.getAttribute("_csrf");
		return  token;
	}
	@PostMapping("/register")
	public User register(@RequestBody User user) {
		return userService.register(user);
	}
	
	@PostMapping("/login")
	public User login(@RequestBody User user) {
		return userService.login(user.getUserName());
	}
}
